import express from "express";
import multer from "multer";
import { execSync } from "child_process";
import fs from "fs";

const app = express();
const upload = multer({ dest: "uploads/" });

app.post("/convert", upload.single("file"), async (req, res) => {
  try {
    const inputPath = req.file.path;
    const outputPath = inputPath + ".blend";

    execSync(`blender --background --python save_as_blend.py -- ${inputPath} ${outputPath}`);

    const fileBuffer = fs.readFileSync(outputPath);
    res.setHeader("Content-Type", "application/octet-stream");
    res.setHeader("Content-Disposition", "attachment; filename=result.blend");
    res.send(fileBuffer);

    fs.unlinkSync(inputPath);
    fs.unlinkSync(outputPath);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao converter o arquivo" });
  }
});

app.get("/", (req, res) => {
  res.send("Blender Worker ativo 🚀");
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Servidor rodando na porta ${port}`));
