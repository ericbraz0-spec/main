import bpy, sys

input_path = sys.argv[sys.argv.index("--")+1]
output_path = sys.argv[sys.argv.index("--")+2]

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=input_path)
bpy.ops.wm.save_as_mainfile(filepath=output_path)
